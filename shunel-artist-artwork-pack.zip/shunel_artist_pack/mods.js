/* SHUNEL — Mod packs locales
 * Compatible con packs individuales y packs de portadas por artista.
 */
const STORAGE_KEY = 'shunel_mods_v1';
const packs = new Map();
let enabledId = null;

const THEME_PROPERTIES = [
  '--shunel-accent',
  '--shunel-background',
  '--shunel-surface',
  '--shunel-text'
];

function isObject(value) {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function safeArtwork(value) {
  if (typeof value !== 'string') return '';
  const url = value.trim();
  return (/^https:\/\//i.test(url) || /^\/assets\/[a-z0-9_./-]+$/i.test(url))
    ? url.slice(0, 1000)
    : '';
}

function normaliseArtist(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function artistParts(value) {
  return String(value || '')
    .replace(/\s+-\s+topic$/i, '')
    .split(/\s*(?:,|;|\||&| feat\.? | ft\.? | featuring | x )\s*/i)
    .map(normaliseArtist)
    .filter(Boolean);
}

function artistMatches(entry, track) {
  const trackArtists = artistParts(track?.artist || track?.channelTitle || '');
  const names = [entry.name, ...(Array.isArray(entry.aliases) ? entry.aliases : [])]
    .map(normaliseArtist)
    .filter(Boolean);
  return names.some(name => trackArtists.includes(name));
}

function validPack(pack) {
  return isObject(pack)
    && typeof pack.id === 'string'
    && /^[a-z0-9_-]{2,48}$/i.test(pack.id)
    && typeof pack.name === 'string';
}

function normalisePack(pack) {
  const artists = Array.isArray(pack.artists)
    ? pack.artists.slice(0, 200).filter(isObject).map(item => ({
        name: String(item.name || '').trim().slice(0, 120),
        aliases: Array.isArray(item.aliases)
          ? item.aliases.filter(value => typeof value === 'string').slice(0, 12).map(value => value.trim().slice(0, 120)).filter(Boolean)
          : [],
        artwork: safeArtwork(item.artwork)
      })).filter(item => item.name)
    : [];

  const themeInput = isObject(pack.theme) ? pack.theme : {};
  const theme = {};
  for (const property of THEME_PROPERTIES) {
    const value = themeInput[property];
    if (typeof value === 'string' && /^(#[\da-f]{3,8}|rgb\([\d\s,.%]+\)|hsl\([\d\s,.%deg]+\))$/i.test(value.trim())) {
      theme[property] = value.trim();
    }
  }

  return {
    id: pack.id,
    name: pack.name.trim().slice(0, 80),
    description: String(pack.description || '').slice(0, 240),
    match: {
      title: String(pack.match?.title || '').slice(0, 160),
      artist: String(pack.match?.artist || '').slice(0, 120),
      videoId: String(pack.match?.videoId || '').slice(0, 32)
    },
    override: {
      title: String(pack.override?.title || '').slice(0, 160),
      artist: String(pack.override?.artist || '').slice(0, 120),
      artwork: safeArtwork(pack.override?.artwork)
    },
    artists,
    theme
  };
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      enabledId,
      packs: [...packs.values()]
    }));
  } catch { /* El almacenamiento local puede estar desactivado o lleno. */ }
}

function readState() {
  try {
    const state = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    if (Array.isArray(state.packs)) {
      for (const item of state.packs) {
        if (validPack(item)) {
          const safe = normalisePack(item);
          packs.set(safe.id, safe);
        }
      }
    }
    enabledId = typeof state.enabledId === 'string' && packs.has(state.enabledId)
      ? state.enabledId
      : null;
  } catch {
    enabledId = null;
  }
}

export function registerModPack(pack) {
  if (!validPack(pack)) throw new TypeError('El pack debe incluir id y name válidos.');
  const safe = normalisePack(pack);
  packs.set(safe.id, safe);
  saveState();
  return safe;
}

export function importModPack(json) {
  const pack = typeof json === 'string' ? JSON.parse(json) : json;
  return registerModPack(pack);
}

export function listModPacks() {
  return [...packs.values()].map(pack => ({
    ...pack,
    enabled: pack.id === enabledId,
    artistCount: pack.artists.length
  }));
}

export function getEnabledModPack() {
  return enabledId ? packs.get(enabledId) || null : null;
}

export function getArtistArtworkEntry(track) {
  const pack = getEnabledModPack();
  if (!pack || !pack.artists.length) return null;
  return pack.artists.find(entry => artistMatches(entry, track)) || null;
}

export function enableModPack(id) {
  if (id !== null && !packs.has(id)) throw new Error('Ese pack no está registrado.');
  enabledId = id;
  saveState();
  applyActiveMod();
  document.dispatchEvent(new CustomEvent('shunel:mods-changed', { detail: { enabledId } }));
}

export function disableModPack() {
  enableModPack(null);
}

function matches(pack, track) {
  const match = pack.match;
  if (match.videoId && match.videoId !== String(track?.videoId || track?.id || '')) return false;
  if (match.title && !String(track?.title || '').toLowerCase().includes(match.title.toLowerCase())) return false;
  if (match.artist && !String(track?.artist || track?.channelTitle || '').toLowerCase().includes(match.artist.toLowerCase())) return false;
  return Boolean(match.videoId || match.title || match.artist);
}

export function applyModToTrack(track) {
  if (!track) return track;
  const pack = getEnabledModPack();
  if (!pack || !matches(pack, track)) return track;
  return {
    ...track,
    title: pack.override.title || track.title,
    artist: pack.override.artist || track.artist || track.channelTitle,
    artwork: pack.override.artwork || track.artwork || track.thumbnail,
    modPackId: pack.id
  };
}

export function applyActiveMod() {
  const root = document.documentElement;
  const pack = getEnabledModPack();
  root.removeAttribute('data-shunel-mod');

  for (const property of THEME_PROPERTIES) root.style.removeProperty(property);
  if (!pack) return;

  root.dataset.shunelMod = pack.id;
  for (const property of THEME_PROPERTIES) {
    const value = pack.theme[property];
    if (value) root.style.setProperty(property, value);
  }
}

readState();
